#ifndef MUL_H
#define MUL_H

using namespace std;

class Mul{
int a,b;
public:
    void setValue(int x, int y);
    int calculate();
};

#endif

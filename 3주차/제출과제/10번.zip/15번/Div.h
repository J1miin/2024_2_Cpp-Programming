#ifndef DIV_H
#define DIV_H
using namespace std;

class Div{
int a,b;
public:
    void setValue(int x, int y);
    int calculate();
};

#endif

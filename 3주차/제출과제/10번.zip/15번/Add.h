#ifndef ADD_H
#define ADD_H

using namespace std;

class Add{
int a,b;
public:
    void setValue(int x, int y);
    int calculate();
};

#endif

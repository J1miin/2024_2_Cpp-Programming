#ifndef SUB_H
#define SUB_H

using namespace std;

class Sub{
int a,b;
public:
    void setValue(int x, int y);
    int calculate();
};

#endif
